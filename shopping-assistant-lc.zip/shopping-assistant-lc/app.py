"""The Shopping Assistant - Streamlit app (Get Skills Network, Python with AI, Level 1, Retail).

Journey: describe a need -> compare real products -> prepare an enquiry.
Python filters, validates and calculates. Gemini (via LangChain, see main.py) interprets the need
and explains trade-offs.
"""
from __future__ import annotations

import io
import os
from datetime import datetime, timezone

import pandas as pd
import streamlit as st

from main import (
    AIError,
    build_llm,
    cache_key,
    compare_products,
    get_env_api_key,
    get_model_name,
    recommend_products,
    sanitize_need,
)
from catalogue import (
    DEFAULT_CATALOGUE_PATH,
    CatalogueError,
    affordable_in_stock,
    catalogue_signature,
    check_budget,
    check_quantity,
    cheapest_in_stock,
    filter_products,
    format_ghs,
    get_product,
    load_catalogue,
)
from enquiry import EnquiryError, build_enquiry

EXAMPLE_NEED = "I need headphones for online classes."
EXAMPLE_BUDGET = 250.0
MAX_CACHED_AI_ANSWERS = 20


st.set_page_config(
    page_title="Yasir Shopping Assistant",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ============================================================
# PROFESSIONAL CSS DESIGN (dark theme)
# ============================================================
st.markdown(
    """
<style>
.stApp { background: linear-gradient(135deg, #07111F, #0A1628, #0D1B2E); color: #EAF2FF; }
.block-container { max-width: 1200px; padding-top: 2rem; padding-bottom: 2rem; }
[data-testid="stSidebar"] { background: #081321; border-right: 1px solid #1B2D44; }
[data-testid="stSidebar"] * { color: #DCE8F7; }
h1, h2, h3 { color: #FFFFFF !important; font-weight: 800 !important; }
p, label, li { line-height: 1.7; }
.brand { color: #48CAE4; font-size: 12px; font-weight: 800; letter-spacing: 3px; }
.hero-title { color: #FFFFFF; font-size: 34px; font-weight: 800; margin: 0; }
.hero-description { color: #A9BCD3; font-size: 15px; }
div[data-testid="stTextInput"] input,
div[data-testid="stTextArea"] textarea,
div[data-testid="stNumberInput"] input {
    background: #0D1B2E !important; color: #FFFFFF !important;
    border: 1px solid #263D59 !important; border-radius: 12px !important;
}
div[data-testid="stTextInput"] input:focus,
div[data-testid="stTextArea"] textarea:focus,
div[data-testid="stNumberInput"] input:focus {
    border-color: #48CAE4 !important; box-shadow: 0 0 0 2px rgba(72,202,228,0.15);
}
div.stButton > button, div.stDownloadButton > button {
    background: linear-gradient(135deg, #00B4D8, #0077B6); color: white; border: none;
    border-radius: 12px; min-height: 46px; font-weight: 700; transition: 0.3s;
}
div.stButton > button:hover, div.stDownloadButton > button:hover {
    background: #48CAE4; color: #FFFFFF; transform: translateY(-2px);
}
[data-testid="stVerticalBlockBorderWrapper"] { background: #10233A; border: 1px solid #263D59; border-radius: 16px; }
hr { border-color: #263D59 !important; }
[data-testid="stAlert"] { border-radius: 12px; }
.custom-footer { text-align: center; color: #8197B2; font-size: 12px; }
@media (max-width: 768px) { .hero-title { font-size: 24px; } .block-container { padding: 1rem; } }
</style>
""",
    unsafe_allow_html=True,
)


# --------------------------------------------------------------------------- #
# Data loading (public, static data is cached; private input is not)
# --------------------------------------------------------------------------- #
@st.cache_data(show_spinner=False)
def load_sample_catalogue(path: str) -> pd.DataFrame:
    return load_catalogue(path)


def _secret(name: str) -> str | None:
    try:
        return st.secrets.get(name)
    except Exception:  # no secrets file present
        return None


def get_api_key() -> str | None:
    return _secret("GOOGLE_API_KEY") or _secret("GEMINI_API_KEY") or get_env_api_key()


def get_model() -> str:
    return (_secret("GEMINI_MODEL") or "").strip() or get_model_name()


@st.cache_resource(show_spinner=False)
def get_llm(api_key: str | None, model: str):
    """Build the LangChain Gemini model once per key/model (raises if no key is set)."""
    return build_llm(api_key, model)


# --------------------------------------------------------------------------- #
# Session state, reset and AI helper
# --------------------------------------------------------------------------- #
DEFAULTS = {
    "rec_need": "",
    "rec_budget": EXAMPLE_BUDGET,
    "rec_state": None,
    "cmp_need": "",
    "cmp_state": None,
    "basket": {},
    "ai_cache": {},
    "customer_name": "",
    "customer_note": "",
    "enquiry_time": None,
    "enquiry_sig": None,
    "catalogue_sig": None,
}


def init_state() -> None:
    for key, value in DEFAULTS.items():
        if key not in st.session_state:
            st.session_state[key] = value.copy() if isinstance(value, (dict, list)) else value


def reset_all() -> None:
    """Clear progress and every widget tied to it (used as a button callback)."""
    for key in list(st.session_state.keys()):
        if key.startswith(("basket_qty_", "add_", "cmp_a", "cmp_b")):
            del st.session_state[key]
    for key, value in DEFAULTS.items():
        st.session_state[key] = value.copy() if isinstance(value, (dict, list)) else value
    st.session_state.rec_need = ""


def run_ai(kind: str, cache_parts: list, call):
    """Run an explicit AI request, reusing a saved answer for identical inputs."""
    key = cache_key(kind, get_model(), *cache_parts)
    cache = st.session_state.ai_cache
    if key in cache:
        return cache[key], True
    llm = get_llm(get_api_key(), get_model())  # raises AINotConfiguredError if no key
    result = call(llm)
    if len(cache) >= MAX_CACHED_AI_ANSWERS:
        cache.pop(next(iter(cache)))
    cache[key] = result
    return result, False


def add_to_basket(df: pd.DataFrame, product_id: str, quantity) -> None:
    """Callback: check stock, then add. Shows a toast either way."""
    product = get_product(df, product_id)
    if product is None:
        st.toast("That product is not in the catalogue.", icon="⚠️")
        return
    basket = st.session_state.basket
    check = check_quantity(product, quantity, already_in_enquiry=basket.get(product_id, 0))
    if not check.ok:
        st.toast(check.message, icon="⚠️")
        return
    basket[product_id] = basket.get(product_id, 0) + int(quantity)
    st.session_state.pop(f"basket_qty_{product_id}", None)  # refresh the editor value
    st.toast(f"Added {int(quantity)} x {product['name']} to your enquiry.", icon="✅")


def add_selected_to_basket(df: pd.DataFrame) -> None:
    """Callback for the Enquiry form: read the widget values at click time (not render time)."""
    add_to_basket(df, st.session_state.add_pid, st.session_state.add_qty)


def remove_from_basket(product_id: str) -> None:
    st.session_state.basket.pop(product_id, None)
    st.session_state.pop(f"basket_qty_{product_id}", None)


def use_example() -> None:
    st.session_state.rec_need = EXAMPLE_NEED
    st.session_state.rec_budget = EXAMPLE_BUDGET


def use_no_match_demo() -> None:
    st.session_state.rec_need = EXAMPLE_NEED
    st.session_state.rec_budget = 10.0


# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
def sidebar() -> pd.DataFrame:
    st.sidebar.markdown("# 🛍️")
    st.sidebar.markdown("<p class='brand'>AI RETAIL PLATFORM</p>", unsafe_allow_html=True)
    st.sidebar.markdown("## Yasir Shopping Assistant")
    st.sidebar.caption("Smart choices. Real stock. Clear enquiries.")
    st.sidebar.divider()

    st.sidebar.subheader("Catalogue")
    upload = st.sidebar.file_uploader(
        "Optional: use your own catalogue CSV",
        type="csv",
        help="Required columns: product_id, name, category, description, price_ghs, stock_qty",
    )
    df = None
    if upload is not None:
        try:
            df = load_catalogue(io.BytesIO(upload.getvalue()))
            st.sidebar.success(f"Using your file ({len(df)} products).")
        except CatalogueError as exc:
            st.sidebar.error(f"{exc} Showing the sample catalogue instead.")
    if df is None:
        try:
            df = load_sample_catalogue(str(DEFAULT_CATALOGUE_PATH))
        except CatalogueError as exc:
            st.error(f"The sample catalogue could not be loaded: {exc}")
            st.stop()
        st.sidebar.caption(f"Sample catalogue: {len(df)} fictional products.")

    sig = catalogue_signature(df)
    if st.session_state.catalogue_sig not in (None, sig):  # catalogue changed -> old picks invalid
        st.session_state.basket = {}
        st.session_state.rec_state = None
        st.session_state.cmp_state = None
        for key in [k for k in st.session_state if k.startswith("basket_qty_")]:
            del st.session_state[key]
    st.session_state.catalogue_sig = sig

    st.sidebar.subheader("AI helper")
    if get_api_key():
        st.sidebar.success(f"AI ready · {get_model()}")
    else:
        st.sidebar.warning("No GOOGLE_API_KEY found. Browsing and enquiries still work.")
    st.sidebar.button("↺ Start over", on_click=reset_all, width="stretch")
    st.sidebar.caption("Clears your request, comparison and enquiry.")
    st.sidebar.divider()
    st.sidebar.markdown("### ⚙️ Platform Features")
    st.sidebar.markdown(
        "🛒 Real catalogue, real stock\n\n🧠 AI-powered recommendations\n\n"
        "⚖️ Side-by-side comparison\n\n📄 Downloadable enquiry"
    )
    st.sidebar.divider()
    st.sidebar.caption("Powered by LangChain, Gemini & Streamlit · Version 1.0.0")
    return df


# --------------------------------------------------------------------------- #
# Tabs
# --------------------------------------------------------------------------- #
def tab_start() -> None:
    st.header("Find the right product, then ask the shop")
    st.write(
        "Tell the assistant what you need and your budget. It only recommends products that are "
        "**in the shop's catalogue, in stock and within your budget**, helps you compare two of "
        "them, and prepares a downloadable **enquiry** for the shop owner."
    )
    c1, c2, c3 = st.columns(3)
    c1.markdown("**1 · Describe a need**\n\nTab *Recommend*: your need and budget in GHS.")
    c2.markdown("**2 · Compare real products**\n\nTab *Compare*: pick two items and see trade-offs.")
    c3.markdown("**3 · Prepare an enquiry**\n\nTab *Enquiry*: choose quantities and download.")

    st.subheader("Try it")
    st.code(f"{EXAMPLE_NEED} My budget is GHS {EXAMPLE_BUDGET:.0f}. "
            "Which available products would you recommend, and why?", language=None)
    b1, b2 = st.columns(2)
    b1.button("Use the example request (GHS 250)", on_click=use_example, width="stretch")
    b2.button("Try a too-small budget (GHS 10)", on_click=use_no_match_demo, width="stretch")
    st.caption("These fill in the *Recommend* tab. Open it and press the button there.")

    with st.expander("Other demo checks"):
        st.markdown(
            "- **Stock check:** in *Enquiry*, choose *Portable Bluetooth Speaker* (out of stock) or ask "
            "for more units than are available. The quantity is rejected.\n"
            "- **No AI key / API failure:** remove the key or use an invalid one; the app shows a "
            "friendly message and everything else keeps working."
        )
    st.info(
        "**Good to know:** this assistant does not take payment and does not send anything to the "
        "shop. The enquiry is a document you share yourself. The shop must confirm price and stock."
    )


def tab_catalogue(df: pd.DataFrame) -> None:
    st.header("Product catalogue")
    c1, c2, c3 = st.columns([2, 1, 1])
    search = c1.text_input("Search", placeholder="e.g. headphones, microphone, USB")
    category = c2.selectbox("Category", ["All", *sorted(df["category"].unique())])
    in_stock_only = c3.toggle("In stock only", value=False)
    lo, hi = float(df["price_ghs"].min()), float(df["price_ghs"].max())
    price_range = (lo, hi)
    if lo < hi:
        price_range = st.slider("Price range (GHS)", lo, hi, (lo, hi))
    view = filter_products(
        df,
        search=search,
        category=category,
        min_price=price_range[0],
        max_price=price_range[1],
        in_stock_only=in_stock_only,
    ).copy()
    view["availability"] = view["stock_qty"].map(lambda q: f"In stock ({q})" if q > 0 else "Out of stock")
    st.caption(f"Showing {len(view)} of {len(df)} products")
    if view.empty:
        st.info("No products match those filters. Try clearing the search or widening the price range.")
        return
    st.dataframe(
        view[["product_id", "name", "category", "description", "price_ghs", "availability"]],
        hide_index=True,
        width="stretch",
        column_config={
            "product_id": "ID",
            "name": "Product",
            "category": "Category",
            "description": st.column_config.TextColumn("Description", width="large"),
            "price_ghs": st.column_config.NumberColumn("Price", format="GHS %.2f"),
            "availability": "Availability",
        },
    )


def tab_recommend(df: pd.DataFrame) -> None:
    st.header("Describe what you need")
    st.text_area(
        "What do you need?",
        key="rec_need",
        max_chars=500,
        placeholder=EXAMPLE_NEED,
        help="Plain language is fine, e.g. what you will use it for.",
    )
    st.number_input("Your budget (GHS)", min_value=0.0, step=10.0, format="%.2f", key="rec_budget")

    if st.button("Get recommendations", type="primary"):
        need = sanitize_need(st.session_state.rec_need)
        budget = st.session_state.rec_budget
        budget_check = check_budget(budget)
        if not need:
            st.warning("Please describe what you need first. Example: " + EXAMPLE_NEED)
        elif not budget_check.ok:
            st.warning(budget_check.message)
        else:
            candidates = affordable_in_stock(df, budget)  # Python decides what is valid
            state = {"need": need, "budget": budget, "candidates": candidates, "result": None, "error": None}
            if not candidates.empty:
                try:
                    with st.spinner("Asking the AI helper..."):
                        result, _ = run_ai(
                            "recommend",
                            [need, float(budget), candidates["product_id"].tolist(), catalogue_signature(df)],
                            lambda llm: recommend_products(llm, need, budget, candidates),
                        )
                    state["result"] = result
                except AIError as exc:
                    state["error"] = str(exc)
            st.session_state.rec_state = state

    state = st.session_state.rec_state
    if not state:
        st.caption("Tip: use the buttons on the Start tab to fill in an example.")
        return

    st.divider()
    st.subheader(f"Results for a budget of {format_ghs(state['budget'])}")
    candidates: pd.DataFrame = state["candidates"]

    if candidates.empty:
        cheapest = cheapest_in_stock(df)
        msg = (
            f"No product in the sample catalogue is in stock at or under {format_ghs(state['budget'])}."
        )
        if cheapest:
            msg += f" The cheapest available item is {cheapest['name']} at {format_ghs(cheapest['price_ghs'])}."
        st.warning(msg + " Try a higher budget, or ask the shop owner about other products.")
        return

    st.caption(
        f"Python found {len(candidates)} in-stock product(s) within budget: "
        + ", ".join(candidates["name"])
        + "."
    )
    if state["error"]:
        st.error(state["error"])
        st.info("You can still browse the in-budget products below, or try again in a moment.")
        show_candidate_table(candidates)
        return

    result = state["result"]
    if result.summary:
        st.write(result.summary)
    if not result.items:
        st.info("None of the in-budget products clearly fit that need. Here is what is within budget:")
        show_candidate_table(candidates)
        return

    for item in result.items:
        product = get_product(df, item.product_id)
        if product is None:
            continue
        with st.container(border=True):
            left, right = st.columns([4, 1])
            left.markdown(f"**{product['name']}** · {format_ghs(product['price_ghs'])} · "
                          f"{product['stock_qty']} in stock")
            left.write(item.reason or product["description"])
            if item.unverified_amount:
                left.caption("⚠️ The AI mentioned a price that could not be verified. "
                             "Use the catalogue price shown above.")
            right.button("Add to enquiry", key=f"add_rec_{product['product_id']}",
                         on_click=add_to_basket, args=(df, product["product_id"], 1), width="stretch")
    if result.dropped:
        st.caption(f"{result.dropped} AI suggestion(s) were removed because they were not valid "
                   "in-stock products within your budget.")
    st.caption("AI explanations use only the catalogue details. The shop must confirm price and stock.")


def show_candidate_table(candidates: pd.DataFrame) -> None:
    st.dataframe(
        candidates[["product_id", "name", "price_ghs", "stock_qty"]],
        hide_index=True,
        width="stretch",
        column_config={"price_ghs": st.column_config.NumberColumn("Price", format="GHS %.2f")},
    )


def tab_compare(df: pd.DataFrame) -> None:
    st.header("Compare two products")
    ids = df["product_id"].tolist()
    labels = {r.product_id: f"{r.name} ({format_ghs(r.price_ghs)})" for r in df.itertuples()}
    c1, c2 = st.columns(2)
    a_id = c1.selectbox("Product A", ids, index=0, format_func=labels.get, key="cmp_a")
    b_id = c2.selectbox("Product B", ids, index=min(1, len(ids) - 1), format_func=labels.get, key="cmp_b")
    a, b = get_product(df, a_id), get_product(df, b_id)

    if a_id == b_id:
        st.warning("Please choose two different products.")
        return

    table = pd.DataFrame(
        {
            "": ["Category", "Price", "Stock", "Description"],
            a["name"]: [a["category"], format_ghs(a["price_ghs"]), _stock_label(a), a["description"]],
            b["name"]: [b["category"], format_ghs(b["price_ghs"]), _stock_label(b), b["description"]],
        }
    )
    st.dataframe(table, hide_index=True, width="stretch")
    diff = abs(a["price_ghs"] - b["price_ghs"])
    cheaper = a if a["price_ghs"] < b["price_ghs"] else b
    if diff:
        st.caption(f"Price difference: {format_ghs(diff)} ({cheaper['name']} is cheaper).")

    st.text_input("What matters most to you? (optional)", key="cmp_need", max_chars=300,
                  placeholder="e.g. clear sound for calls, battery life")
    if st.button("Explain the trade-offs with AI", type="primary"):
        need = sanitize_need(st.session_state.cmp_need or st.session_state.rec_need)
        state = {"a_id": a_id, "b_id": b_id, "result": None, "error": None}
        try:
            with st.spinner("Asking the AI helper..."):
                result, _ = run_ai(
                    "compare",
                    [a_id, b_id, need, catalogue_signature(df)],
                    lambda llm: compare_products(llm, a, b, need),
                )
            state["result"] = result
        except AIError as exc:
            state["error"] = str(exc)
        st.session_state.cmp_state = state

    state = st.session_state.cmp_state
    if state and (state["a_id"], state["b_id"]) == (a_id, b_id):
        if state["error"]:
            st.error(state["error"])
        else:
            res = state["result"]
            st.subheader("Trade-offs")
            if res.summary:
                st.write(res.summary)
            for point in res.trade_offs:
                st.markdown(f"- {point}")
            if res.choose_a_if:
                st.markdown(f"**Choose {a['name']} if:** {res.choose_a_if}")
            if res.choose_b_if:
                st.markdown(f"**Choose {b['name']} if:** {res.choose_b_if}")
            if res.unverified_amount:
                st.caption("⚠️ The AI mentioned a price that could not be verified. Use the prices in the table.")

    st.divider()
    b1, b2 = st.columns(2)
    b1.button(f"Add {a['name']} to enquiry", key="add_cmp_a", on_click=add_to_basket,
              args=(df, a_id, 1), width="stretch")
    b2.button(f"Add {b['name']} to enquiry", key="add_cmp_b", on_click=add_to_basket,
              args=(df, b_id, 1), width="stretch")


def _stock_label(product: dict) -> str:
    return f"{product['stock_qty']} available" if product["stock_qty"] > 0 else "Out of stock"


def tab_enquiry(df: pd.DataFrame) -> None:
    st.header("Prepare your enquiry")
    st.caption("An enquiry is a request for the shop owner to confirm price and stock. It is not an order.")
    ids = df["product_id"].tolist()
    labels = {
        r.product_id: f"{r.name} · {format_ghs(r.price_ghs)}"
        + ("" if r.stock_qty > 0 else " · OUT OF STOCK")
        for r in df.itertuples()
    }
    c1, c2, c3 = st.columns([3, 1, 1])
    c1.selectbox("Product", ids, format_func=labels.get, key="add_pid")
    c2.number_input("Quantity", min_value=0, value=1, step=1, key="add_qty")
    c3.write("")
    c3.write("")
    c3.button("Add to enquiry", on_click=add_selected_to_basket, args=(df,), width="stretch")

    basket: dict = st.session_state.basket
    st.subheader("Your enquiry")
    if not basket:
        st.info("Nothing here yet. Add a product above, or from the Recommend and Compare tabs.")
        return

    for product_id in list(basket):
        product = get_product(df, product_id)
        if product is None:
            basket.pop(product_id)
            continue
        col_a, col_b, col_c = st.columns([4, 1.5, 1])
        col_a.markdown(f"**{product['name']}**  \n{format_ghs(product['price_ghs'])} each · "
                       f"{product['stock_qty']} in stock")
        new_qty = col_b.number_input("Quantity", min_value=0, value=int(basket[product_id]), step=1,
                                     key=f"basket_qty_{product_id}", label_visibility="collapsed")
        basket[product_id] = int(new_qty)
        col_c.button("Remove", key=f"rm_{product_id}", on_click=remove_from_basket, args=(product_id,))
        check = check_quantity(product, basket[product_id])
        if not check.ok:
            st.error(check.message)

    try:
        sig = str(sorted(basket.items()))
        if st.session_state.enquiry_sig != sig or st.session_state.enquiry_time is None:
            st.session_state.enquiry_sig = sig
            st.session_state.enquiry_time = datetime.now(timezone.utc)
        enquiry = build_enquiry(
            df, basket,
            customer_name=st.session_state.customer_name,
            note=st.session_state.customer_note,
            now=st.session_state.enquiry_time,
        )
    except EnquiryError:
        st.warning("Fix the quantities above to see your total and download the enquiry.")
        return

    st.metric("Estimated total (calculated by Python)", format_ghs(enquiry.total))
    st.text_input("Your name (optional)", key="customer_name", max_chars=80)
    st.text_area("Note for the shop owner (optional)", key="customer_note", max_chars=500)
    enquiry = build_enquiry(df, basket, customer_name=st.session_state.customer_name,
                            note=st.session_state.customer_note, now=st.session_state.enquiry_time)

    with st.expander("Preview the enquiry", expanded=True):
        st.code(enquiry.to_text(), language=None)
    d1, d2 = st.columns(2)
    d1.download_button("⬇ Download enquiry (.txt)", enquiry.to_text(),
                       file_name=f"{enquiry.reference}.txt", mime="text/plain", width="stretch")
    d2.download_button("⬇ Download enquiry (.csv)", enquiry.to_csv(),
                       file_name=f"{enquiry.reference}.csv", mime="text/csv", width="stretch")
    st.caption("Nothing has been sent to the shop and no payment has been taken. "
               "Share the downloaded enquiry with the shop owner yourself.")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def header() -> None:
    st.markdown("<p class='brand'>AI-POWERED SHOPPING PLATFORM</p>", unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown("<p class='hero-title'>Yasir Shopping Assistant 🛍️</p>", unsafe_allow_html=True)
        st.markdown(
            "<p class='hero-description'>Describe what you need, compare real products from the "
            "shop's catalogue, and prepare a clear enquiry for the shop owner.</p>",
            unsafe_allow_html=True,
        )
        st.success("SHOPPING ASSISTANT ACTIVE")


def footer() -> None:
    st.divider()
    st.markdown(
        """
        <div class="custom-footer">
            Built with ❤️ using Streamlit, LangChain and Gemini
            <br><br>
            <strong>Yasir Shopping Assistant</strong> | AI-Powered Retail Helper
        </div>
        """,
        unsafe_allow_html=True,
    )


def main() -> None:
    init_state()
    df = sidebar()
    header()
    start, catalogue_tab, recommend, compare, enquiry_tab = st.tabs(
        ["Start", "Catalogue", "Recommend", "Compare", "Enquiry"]
    )
    with start:
        tab_start()
    with catalogue_tab:
        tab_catalogue(df)
    with recommend:
        tab_recommend(df)
    with compare:
        tab_compare(df)
    with enquiry_tab:
        tab_enquiry(df)
    footer()


main()
