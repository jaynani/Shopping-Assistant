"""Catalogue logic for the Shopping Assistant.

Everything here is plain Python/pandas. The AI never decides what is in stock,
what fits a budget or what a total is - this module does.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from typing import Mapping, Optional

import pandas as pd

REQUIRED_COLUMNS = ["product_id", "name", "category", "description", "price_ghs", "stock_qty"]
TEXT_COLUMNS = ["product_id", "name", "category", "description"]
DEFAULT_CATALOGUE_PATH = Path(__file__).parent / "data" / "retail_sample_catalogue.csv"
MAX_BUDGET_GHS = 1_000_000


class CatalogueError(ValueError):
    """Raised when a catalogue file is missing columns or holds invalid values."""


@dataclass(frozen=True)
class QuantityCheck:
    ok: bool
    message: str


# --------------------------------------------------------------------------- #
# Loading and validation
# --------------------------------------------------------------------------- #
def validate_catalogue(df: pd.DataFrame) -> pd.DataFrame:
    """Return a clean copy of ``df`` or raise CatalogueError with a clear reason."""
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise CatalogueError(f"The catalogue is missing required column(s): {', '.join(missing)}.")
    df = df[REQUIRED_COLUMNS]
    if df.empty:
        raise CatalogueError("The catalogue has no products.")

    # Text columns must be present and non-blank.
    for col in TEXT_COLUMNS:
        blank = df[col].isna() | (df[col].astype(str).str.strip() == "")
        if blank.any():
            rows = ", ".join(str(i + 2) for i in df.index[blank][:5])  # +2: header + 1-based
            raise CatalogueError(f"Column '{col}' has empty values (file row(s): {rows}).")
        df[col] = df[col].astype(str).str.strip()

    if df["product_id"].duplicated().any():
        dupes = ", ".join(df.loc[df["product_id"].duplicated(), "product_id"].unique()[:5])
        raise CatalogueError(f"Duplicate product_id value(s): {dupes}.")

    # Prices: numeric and > 0.
    price = pd.to_numeric(df["price_ghs"], errors="coerce")
    if price.isna().any():
        rows = ", ".join(str(i + 2) for i in df.index[price.isna()][:5])
        raise CatalogueError(f"price_ghs must be a number (file row(s): {rows}).")
    if (price <= 0).any():
        rows = ", ".join(str(i + 2) for i in df.index[price <= 0][:5])
        raise CatalogueError(f"price_ghs must be greater than 0 (file row(s): {rows}).")

    # Stock: whole number >= 0.
    stock = pd.to_numeric(df["stock_qty"], errors="coerce")
    if stock.isna().any():
        rows = ", ".join(str(i + 2) for i in df.index[stock.isna()][:5])
        raise CatalogueError(f"stock_qty must be a number (file row(s): {rows}).")
    if (stock < 0).any() or ((stock % 1) != 0).any():
        bad = (stock < 0) | ((stock % 1) != 0)
        rows = ", ".join(str(i + 2) for i in df.index[bad][:5])
        raise CatalogueError(f"stock_qty must be a whole number, 0 or more (file row(s): {rows}).")

    df["price_ghs"] = price.astype(float)
    df["stock_qty"] = stock.astype(int)
    return df.reset_index(drop=True)


def load_catalogue(source=DEFAULT_CATALOGUE_PATH) -> pd.DataFrame:
    """Read a CSV (path or file-like) and validate it."""
    try:
        raw = pd.read_csv(source, dtype=str, keep_default_na=False, na_values=[""])
    except FileNotFoundError as exc:
        raise CatalogueError("The catalogue file could not be found.") from exc
    except (pd.errors.EmptyDataError, pd.errors.ParserError, UnicodeDecodeError) as exc:
        raise CatalogueError("The file could not be read as a CSV catalogue.") from exc
    return validate_catalogue(raw)


# --------------------------------------------------------------------------- #
# Money helpers (Decimal so totals are exact)
# --------------------------------------------------------------------------- #
def to_money(value) -> Decimal:
    return Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def format_ghs(value) -> str:
    return f"GHS {to_money(value):,.2f}"


def line_total(unit_price, quantity: int) -> Decimal:
    return to_money(to_money(unit_price) * int(quantity))


# --------------------------------------------------------------------------- #
# Budget, filtering and lookups
# --------------------------------------------------------------------------- #
def check_budget(value) -> QuantityCheck:
    """Validate a customer budget (a positive, sensible amount in GHS)."""
    try:
        amount = Decimal(str(value))
    except Exception:
        return QuantityCheck(False, "Please enter your budget as a number.")
    if not amount.is_finite() or amount <= 0:
        return QuantityCheck(False, "Your budget must be greater than GHS 0.")
    if amount > MAX_BUDGET_GHS:
        return QuantityCheck(False, f"Please enter a budget of GHS {MAX_BUDGET_GHS:,} or less.")
    return QuantityCheck(True, "")


def filter_products(
    df: pd.DataFrame,
    *,
    search: str = "",
    category: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    in_stock_only: bool = False,
) -> pd.DataFrame:
    out = df
    if search and search.strip():
        term = search.strip()
        mask = (
            out["name"].str.contains(term, case=False, regex=False)
            | out["description"].str.contains(term, case=False, regex=False)
            | out["category"].str.contains(term, case=False, regex=False)
        )
        out = out[mask]
    if category and category != "All":
        out = out[out["category"] == category]
    if min_price is not None:
        out = out[out["price_ghs"] >= min_price]
    if max_price is not None:
        out = out[out["price_ghs"] <= max_price]
    if in_stock_only:
        out = out[out["stock_qty"] > 0]
    return out


def affordable_in_stock(df: pd.DataFrame, budget: float) -> pd.DataFrame:
    """Products that are in stock and priced at or under the budget (Python decides)."""
    return df[(df["stock_qty"] > 0) & (df["price_ghs"] <= float(budget))].sort_values("price_ghs")


def cheapest_in_stock(df: pd.DataFrame) -> Optional[Mapping]:
    in_stock = df[df["stock_qty"] > 0]
    if in_stock.empty:
        return None
    return in_stock.sort_values("price_ghs").iloc[0].to_dict()


def get_product(df: pd.DataFrame, product_id: str) -> Optional[dict]:
    match = df[df["product_id"] == product_id]
    return None if match.empty else match.iloc[0].to_dict()


def check_quantity(product: Mapping, quantity, already_in_enquiry: int = 0) -> QuantityCheck:
    """Validate a requested quantity against the product's stock.

    ``already_in_enquiry`` counts units of the same product already chosen, so the
    customer cannot exceed stock by adding the same item twice.
    """
    name = product["name"]
    stock = int(product["stock_qty"])

    if isinstance(quantity, bool) or not isinstance(quantity, (int, float)):
        return QuantityCheck(False, "Quantity must be a whole number.")
    if isinstance(quantity, float) and not quantity.is_integer():
        return QuantityCheck(False, "Quantity must be a whole number.")
    quantity = int(quantity)

    if quantity < 1:
        return QuantityCheck(False, "Quantity must be at least 1.")
    if stock <= 0:
        return QuantityCheck(False, f"{name} is out of stock, so it cannot be added.")
    if quantity + already_in_enquiry > stock:
        available = max(stock - already_in_enquiry, 0)
        return QuantityCheck(
            False,
            f"Only {stock} unit(s) of {name} are in stock "
            f"({available} more can be added). Please reduce the quantity.",
        )
    return QuantityCheck(True, "")


def catalogue_signature(df: pd.DataFrame) -> str:
    """Cheap fingerprint used to reset saved progress if the catalogue changes."""
    return str(pd.util.hash_pandas_object(df, index=False).sum())
