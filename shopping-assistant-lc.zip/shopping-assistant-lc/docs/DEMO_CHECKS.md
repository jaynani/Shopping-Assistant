# Demo checks and results

Environment: Python 3.12, uv, Streamlit 1.67, LangChain 1.5, langchain-google-genai 4.5, model `gemini-flash-lite-latest`.
Automated checks: `uv run pytest -q` → **60 passed** (AI faked, so they run offline).
Raw outputs: `docs/sample_outputs/`.

## 1. Normal journey: headphones under GHS 250
- Need: *"I need headphones for online classes."* Budget: **GHS 250**.
- Python's candidates (in stock, ≤ 250): Power Bank GHS 95, Wired Classroom Headphones GHS 120, HD USB Webcam GHS 210,
  Bluetooth Study Headphones GHS 230. Noise-Cancelling Headphones Pro (GHS 480) and the speaker (out of stock) are excluded.
- Gemini then chooses/explains the suitable ones; invented IDs are dropped by validation.
- Compare *Wired Classroom Headphones* vs *Bluetooth Study Headphones* → table + trade-offs, then add to enquiry.
- Download enquiry: `docs/sample_outputs/sample_enquiry.txt` / `.csv` (total `GHS 420.00` = 230 + 2 × 95, calculated in Python).
- **Result:** ✅ (logic and UI flow verified by automated tests; paste your live Gemini answer below).

## 2. No match: GHS 10 budget
- Result: *"No product in the sample catalogue is in stock at or under GHS 10.00. The cheapest available item is 10000mAh Power Bank at GHS 95.00."*
- The AI is **not called**, so nothing can be invented. ✅ (`test_no_match_budget_10_makes_no_ai_call`)

## 3. Stock check
| Attempt | Result |
|---|---|
| Portable Bluetooth Speaker × 1 | Rejected: out of stock |
| Wired Classroom Headphones × 16 (stock 15) | Rejected: only 15 in stock |
| Wired Classroom Headphones × 0 | Rejected: quantity must be at least 1 |
| Wired Classroom Headphones × 15 | Accepted |
| Add 10 then 6 of the same item (stock 15) | Second add rejected (cannot exceed stock) |

## 4. API-failure checks
| Situation | Message shown | How to reproduce |
|---|---|---|
| No key | "The AI helper is not set up yet. Add GOOGLE_API_KEY…" | Start the app with no key set |
| Invalid key | "The AI service rejected the request. Please check that the API key is valid…" | Set `GOOGLE_API_KEY=wrong` |
| Quota / rate limit | "The AI service is busy or the usage limit was reached…" | Simulated in tests (429 / RESOURCE_EXHAUSTED) |
| Network down | "We could not reach the AI service…" | Disconnect and press the button |
| Malformed AI output | "The AI answer was not in the expected format…" | Covered in `test_ai_validation.py` |

In every case the catalogue, comparison table and enquiry download keep working.

## 5. Your live results (fill in after running with your key)
- Recommendation output for the example request: _paste here_
- Comparison output: _paste here_
- Deployed app link: _paste here_ · GitHub link: _paste here_

## 6. Be ready to
- **Explain a function:** `check_quantity()` in `catalogue.py` or `run_chain()` in `main.py`.
- **Handle a failure:** remove the key, press *Get recommendations*, show the friendly message.
- **Make a small change:** e.g. change `MAX_RECOMMENDATIONS` in `main.py`, or add a new category filter.
- **Discuss a limitation:** the AI only knows the short catalogue descriptions; stock is not reserved.
