# 🛍️ Yasir Shopping Assistant

**Get Skills Network · Python with AI · Level 1 · Retail**
Stack: Python · Streamlit · LangChain · Google Gemini (`gemini-flash-lite-latest`) · managed with `uv`

## Problem and user
A shop owner answers the same product questions every day, and customers struggle to compare options, stay within
budget and find items that are in stock. The app lets a customer **describe a need → compare real products →
prepare an enquiry** for the shop owner.

## Features
- **Catalogue:** CSV loaded and validated (columns, numeric prices/stock); searchable and filterable table; optional upload of your own CSV.
- **Recommend:** Python keeps only products that are in stock and within budget; Gemini (LangChain) picks and explains the ones that fit the need.
- **Compare:** side-by-side table and price difference from Python; Gemini explains trade-offs using only catalogue details.
- **Enquiry:** multi-product basket with editable quantities, stock checks, a Python-calculated total, and a `.txt` / `.csv` download labelled **ENQUIRY – NOT A CONFIRMED ORDER**.
- **Safety:** no payment, no "order sent" claims, no invented products, discounts or specs.

## Who does what
| Python (exact) | Gemini via LangChain (language) |
|---|---|
| CSV validation, budget and in-stock filtering | Interpreting the customer's need |
| Quantity checks and all totals (`Decimal`) | Choosing among already-valid products |
| Checking every AI answer | Explaining trade-offs |

LangChain is used in `main.py`: `ChatGoogleGenerativeAI` (Gemini) with `ChatPromptTemplate | llm | StrOutputParser`.
Answers come back as JSON and are validated: invented, out-of-budget, out-of-stock or duplicate `product_id`s are dropped,
and any GHS amount that is not a catalogue price, your budget or a simple difference is flagged. Prices on cards always come from the catalogue.

## Setup with uv
```bash
# install uv once: https://docs.astral.sh/uv/getting-started/installation/
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>
uv sync                      # creates .venv and installs everything from uv.lock
cp .env.example .env         # Windows: copy .env.example .env
```
Edit `.env`:
```
GOOGLE_API_KEY=your-gemini-key-here
GEMINI_MODEL=gemini-flash-lite-latest
```
(`GEMINI_API_KEY` is also accepted. Never commit `.env`; it is in `.gitignore`.)

## Run
```bash
uv run python main.py        # optional: command-line check that your key and model work
uv run streamlit run app.py  # start the app
uv run pytest -q             # 60 tests, no key or network needed
```

## Deploy (Streamlit Community Cloud)
1. Push the repo to GitHub (`requirements.txt` is included and generated from `uv.lock` with `uv export --no-dev --no-hashes --no-emit-project -o requirements.txt`).
2. On share.streamlit.io choose the repo and `app.py`.
3. **App settings → Secrets:** `GOOGLE_API_KEY = "your-key"` and `GEMINI_MODEL = "gemini-flash-lite-latest"`.
4. Open the live link in a private window and run the checks in `docs/DEMO_CHECKS.md`.

## Layout
```
app.py                 Streamlit UI (dark theme, tabs, session state, callbacks)
main.py                LangChain + Gemini: LLM setup, chains, validation, safe errors
catalogue.py           CSV loading/validation, filtering, budget and quantity checks, money helpers
enquiry.py             Basket validation, Python totals, .txt/.csv rendering
data/retail_sample_catalogue.csv   Fictional six-product catalogue (speaker is out of stock)
tests/                 60 tests: logic, enquiry, LangChain/AI validation, end-to-end app flows
docs/                  DEMO_CHECKS.md and sample outputs
pyproject.toml, uv.lock, requirements.txt, .env.example, .streamlit/
```

## How behaviour is managed (for your explanation)
- **Conditions:** `check_quantity()` rejects non-integers, quantities < 1, out-of-stock items and totals above stock (including units already chosen). If `affordable_in_stock()` returns nothing, the AI is **not called**.
- **Dictionary:** `st.session_state.basket` = `{product_id: quantity}`; `build_enquiry()` re-validates every entry before download.
- **DataFrame/list:** the filtered candidate list is the only product data sent to the model.

## Caching, memory and reset
`st.cache_data` caches the public sample catalogue and `st.cache_resource` caches the LangChain model object. Private input and AI answers live in `st.session_state`. AI calls happen only on a button press; identical requests reuse a saved answer, so unrelated widgets never trigger a new paid request. Each call is stand-alone (no chat history is resent). **↺ Start over** clears everything.

## Failure handling
Missing key, invalid key, quota (429), model not found, server and network errors, empty or malformed AI output, bad CSVs, empty need, invalid budget and invalid quantities all show plain messages. Keys and raw exception text are never shown.

## Known limitations
- The AI only knows the short catalogue descriptions.
- The enquiry is a file the customer shares themselves; nothing is sent to the shop and stock is not reserved.
- GHS only; no tax, delivery or discount logic by design.
- Free-tier Gemini limits can return 429 errors during heavy use.

## Contributors
| Name | Contribution |
|---|---|
| _Your name_ | _e.g. catalogue logic, LangChain integration, UI, tests, deployment_ |

## Suggested commits
`Add catalogue validation` · `Add budget and stock filters` · `Add LangChain Gemini recommendations` · `Add comparison tab` · `Add enquiry download` · `Add tests and README`.
