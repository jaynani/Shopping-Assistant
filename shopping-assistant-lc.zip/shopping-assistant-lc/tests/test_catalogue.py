import io

import pytest

from catalogue import (
    CatalogueError, affordable_in_stock, check_budget, check_quantity, cheapest_in_stock,
    filter_products, format_ghs, get_product, line_total, load_catalogue,
)


@pytest.fixture(scope="module")
def df():
    return load_catalogue()


def csv(text):
    return io.StringIO(text)


HEADER = "product_id,name,category,description,price_ghs,stock_qty\n"


def test_sample_catalogue_loads_with_six_products(df):
    assert len(df) == 6
    assert df["price_ghs"].dtype == float and df["stock_qty"].dtype == int


def test_missing_column_is_reported():
    with pytest.raises(CatalogueError, match="stock_qty"):
        load_catalogue(csv("product_id,name,category,description,price_ghs\nP1,A,B,C,5\n"))


@pytest.mark.parametrize("row,msg", [
    ("P1,A,B,C,abc,5", "price_ghs must be a number"),
    ("P1,A,B,C,-5,5", "greater than 0"),
    ("P1,A,B,C,5,x", "stock_qty must be a number"),
    ("P1,A,B,C,5,-1", "whole number"),
    ("P1,A,B,C,5,2.5", "whole number"),
    ("P1,,B,C,5,2", "empty values"),
])
def test_invalid_rows_rejected(row, msg):
    with pytest.raises(CatalogueError, match=msg):
        load_catalogue(csv(HEADER + row + "\n"))


def test_duplicate_ids_rejected():
    with pytest.raises(CatalogueError, match="Duplicate"):
        load_catalogue(csv(HEADER + "P1,A,B,C,5,1\nP1,D,E,F,6,2\n"))


def test_empty_and_garbage_files_rejected():
    with pytest.raises(CatalogueError):
        load_catalogue(csv(""))
    with pytest.raises(CatalogueError):
        load_catalogue(csv(HEADER))


def test_headphones_under_250(df):
    names = list(affordable_in_stock(df, 250)["name"])
    assert "Wired Classroom Headphones" in names
    assert "Bluetooth Study Headphones" in names
    assert "Noise-Cancelling Headphones Pro" not in names  # over budget
    assert "Portable Bluetooth Speaker" not in names  # out of stock


def test_budget_of_10_has_no_match(df):
    assert affordable_in_stock(df, 10).empty
    assert cheapest_in_stock(df)["name"] == "10000mAh Power Bank"


def test_budget_boundary_is_inclusive(df):
    assert "P002" in set(affordable_in_stock(df, 230)["product_id"])
    assert "P002" not in set(affordable_in_stock(df, 229.99)["product_id"])


@pytest.mark.parametrize("value,ok", [(250, True), (0, False), (-5, False), ("abc", False),
                                      (float("nan"), False), (float("inf"), False), (10**9, False)])
def test_check_budget(value, ok):
    assert check_budget(value).ok is ok


def test_filters(df):
    assert set(filter_products(df, search="HEADPHONES")["product_id"]) == {"P001", "P002", "P003"}
    assert list(filter_products(df, category="Speakers")["product_id"]) == ["P004"]
    assert "P004" not in set(filter_products(df, in_stock_only=True)["product_id"])
    assert set(filter_products(df, max_price=120)["product_id"]) == {"P001", "P006"}
    assert filter_products(df, search="zzz").empty


def test_quantity_checks(df):
    wired = get_product(df, "P001")      # stock 15
    speaker = get_product(df, "P004")    # stock 0
    assert check_quantity(wired, 15).ok
    assert not check_quantity(wired, 16).ok
    assert not check_quantity(wired, 0).ok
    assert not check_quantity(wired, -2).ok
    assert not check_quantity(wired, 1.5).ok
    assert not check_quantity(wired, "3").ok
    assert not check_quantity(wired, True).ok
    assert not check_quantity(speaker, 1).ok
    assert "out of stock" in check_quantity(speaker, 1).message
    # the same item added twice cannot exceed stock
    assert not check_quantity(wired, 10, already_in_enquiry=6).ok


def test_money_is_exact():
    assert str(line_total(0.1, 3)) == "0.30"
    assert str(line_total(230, 2)) == "460.00"
    assert format_ghs(1234.5) == "GHS 1,234.50"
