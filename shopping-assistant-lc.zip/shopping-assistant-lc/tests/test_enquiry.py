from datetime import datetime, timezone
from decimal import Decimal

import pytest

from catalogue import load_catalogue
from enquiry import EnquiryError, build_enquiry

NOW = datetime(2026, 11, 10, 9, 30, tzinfo=timezone.utc)


@pytest.fixture(scope="module")
def df():
    return load_catalogue()


def test_total_is_calculated_in_python(df):
    enq = build_enquiry(df, {"P001": 2, "P002": 1}, now=NOW)
    assert enq.total == Decimal("470.00")  # 2*120 + 230
    assert [ln.line_total for ln in enq.lines] == [Decimal("240.00"), Decimal("230.00")]
    assert enq.reference == "ENQ-20261110-093000"


def test_empty_basket_rejected(df):
    with pytest.raises(EnquiryError):
        build_enquiry(df, {})


def test_out_of_stock_and_too_many_rejected(df):
    with pytest.raises(EnquiryError) as exc:
        build_enquiry(df, {"P004": 1, "P001": 99})
    assert len(exc.value.problems) == 2


def test_unknown_product_rejected(df):
    with pytest.raises(EnquiryError, match="not in the catalogue"):
        build_enquiry(df, {"NOPE": 1})


def test_text_is_clearly_an_enquiry(df):
    text = build_enquiry(df, {"P001": 1}, customer_name="Ama", note="Call me\x00 after 5pm", now=NOW).to_text()
    assert "NOT A CONFIRMED ORDER" in text
    assert "No payment has been taken" in text
    assert "Estimated total: GHS 120.00" in text
    assert "\x00" not in text and "Ama" in text
    assert "paid" not in text.lower().replace("no payment", "")


def test_csv_output(df):
    csv_text = build_enquiry(df, {"P001": 2}, now=NOW).to_csv()
    assert "ENQUIRY - NOT A CONFIRMED ORDER" in csv_text
    assert "estimated_total_ghs,240.00" in csv_text
