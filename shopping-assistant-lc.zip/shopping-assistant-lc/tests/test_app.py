"""End-to-end checks of the Streamlit app using Streamlit's AppTest (no network, fake AI)."""
import json
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

import main as ai
import streamlit as st
from langchain_core.runnables import RunnableLambda

APP = str(Path(__file__).resolve().parents[1] / "app.py")


class FakeGemini:
    calls = 0
    error = None

    @classmethod
    def llm(cls):
        def respond(prompt_value):
            cls.calls += 1
            if cls.error:
                raise cls.error
            prompt = prompt_value.to_string()
            if "product_a" in prompt:
                return json.dumps({"summary": "Wired is cheaper; Bluetooth is wireless.",
                                   "trade_offs": ["Price vs convenience"],
                                   "choose_a_if": "You want the lowest price.", "choose_b_if": "You want wireless."})
            return json.dumps({"summary": "Two options suit online classes.", "recommendations": [
                {"product_id": "P002", "reason": "Wireless with a microphone."},
                {"product_id": "P001", "reason": "Cheapest with a microphone."},
                {"product_id": "P999", "reason": "Invented product."}]})
        return RunnableLambda(respond)


@pytest.fixture(autouse=True)
def fake_ai(monkeypatch):
    FakeGemini.calls, FakeGemini.error = 0, None
    st.cache_resource.clear()

    def fake_build_llm(api_key=None, model=None):
        if not (api_key or "").strip():
            raise ai.AINotConfiguredError("The AI helper is not set up yet. Add GOOGLE_API_KEY.")
        return FakeGemini.llm()

    monkeypatch.setattr(ai, "build_llm", fake_build_llm)
    monkeypatch.setenv("GOOGLE_API_KEY", "test-key")
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)


def button(at, label):
    return next(b for b in at.button if label in b.label)


def start():
    at = AppTest.from_file(APP, default_timeout=30).run()
    assert not at.exception
    return at


def test_normal_journey_headphones_under_250():
    at = start()
    at.text_area(key="rec_need").set_value("I need headphones for online classes.")
    at.number_input(key="rec_budget").set_value(250.0)
    button(at, "Get recommendations").click().run()
    assert not at.exception
    page = " ".join(m.value for m in at.markdown)
    assert "Bluetooth Study Headphones" in page and "Wired Classroom Headphones" in page
    assert "Noise-Cancelling" not in page and "Invented" not in page
    assert FakeGemini.calls == 1
    # unrelated widget changes must not trigger another AI request
    at.text_input[0].set_value("headphones").run()
    assert FakeGemini.calls == 1
    # add to enquiry, then build it
    button(at, "Add to enquiry").click().run()
    assert at.session_state.basket == {"P002": 1}


def test_no_match_budget_10_makes_no_ai_call():
    at = start()
    at.text_area(key="rec_need").set_value("I need headphones for online classes.")
    at.number_input(key="rec_budget").set_value(10.0)
    button(at, "Get recommendations").click().run()
    assert any("No product in the sample catalogue" in w.value for w in at.warning)
    assert FakeGemini.calls == 0


def test_empty_need_is_rejected():
    at = start()
    button(at, "Get recommendations").click().run()
    assert any("describe what you need" in w.value for w in at.warning)


def test_missing_api_key_shows_friendly_message(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    at = start()
    at.text_area(key="rec_need").set_value("headphones")
    button(at, "Get recommendations").click().run()
    assert not at.exception
    assert any("GOOGLE_API_KEY" in e.value for e in at.error)


def test_api_failure_shows_safe_message():
    FakeGemini.error = RuntimeError("429 RESOURCE_EXHAUSTED secret-detail-123")
    at = start()
    at.text_area(key="rec_need").set_value("headphones")
    button(at, "Get recommendations").click().run()
    assert not at.exception
    assert any("usage limit" in e.value for e in at.error)
    assert not any("secret-detail-123" in e.value for e in at.error)


def test_compare_two_products():
    at = start()
    button(at, "Explain the trade-offs").click().run()
    assert not at.exception
    assert "Price vs convenience" in " ".join(m.value for m in at.markdown)


def test_stock_checks_reject_bad_quantities():
    at = start()
    # out-of-stock speaker
    at.selectbox(key="add_pid").set_value("P004")
    button(at, "Add to enquiry").click().run()
    assert at.session_state.basket == {}
    # more than available (wired headphones: 15)
    at.selectbox(key="add_pid").set_value("P001")
    at.number_input(key="add_qty").set_value(16)
    button(at, "Add to enquiry").click().run()
    assert at.session_state.basket == {}
    # zero is invalid
    at.number_input(key="add_qty").set_value(0)
    button(at, "Add to enquiry").click().run()
    assert at.session_state.basket == {}
    # valid quantity works and the total is exact
    at.number_input(key="add_qty").set_value(2)
    button(at, "Add to enquiry").click().run()
    assert at.session_state.basket == {"P001": 2}
    assert any(m.value == "GHS 240.00" for m in at.metric)


def test_reset_clears_progress():
    at = start()
    at.number_input(key="add_qty").set_value(1)
    button(at, "Add to enquiry").click().run()
    assert at.session_state.basket
    button(at, "Start over").click().run()
    assert at.session_state.basket == {} and not at.exception
