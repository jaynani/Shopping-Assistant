"""Build the downloadable order enquiry. Totals are calculated here, never by the AI."""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Mapping

import pandas as pd

from catalogue import check_quantity, format_ghs, get_product, line_total, to_money

MAX_NOTE_LENGTH = 500
MAX_NAME_LENGTH = 80
DISCLAIMER = (
    "THIS IS AN ENQUIRY, NOT A CONFIRMED ORDER. No payment has been taken and nothing has "
    "been sent to the shop. Prices and stock come from the shop's catalogue and must be "
    "confirmed by the shop owner."
)


class EnquiryError(ValueError):
    """Raised when the basket cannot be turned into a valid enquiry."""

    def __init__(self, problems: list[str]):
        super().__init__("; ".join(problems))
        self.problems = problems


@dataclass(frozen=True)
class EnquiryLine:
    product_id: str
    name: str
    unit_price: Decimal
    quantity: int
    line_total: Decimal


@dataclass
class Enquiry:
    lines: list[EnquiryLine]
    total: Decimal
    reference: str
    created_at: datetime
    customer_name: str = ""
    note: str = ""
    problems: list[str] = field(default_factory=list)

    # ---- rendering -------------------------------------------------------- #
    def to_text(self) -> str:
        out = ["PRODUCT ENQUIRY (NOT A CONFIRMED ORDER)", "=" * 42, ""]
        out.append(f"Reference : {self.reference}")
        out.append(f"Prepared  : {self.created_at.strftime('%Y-%m-%d %H:%M UTC')}")
        if self.customer_name:
            out.append(f"Customer  : {self.customer_name}")
        out += ["", "Items requested", "-" * 42]
        for i, ln in enumerate(self.lines, start=1):
            out.append(f"{i}. {ln.name} [{ln.product_id}]")
            out.append(
                f"   {ln.quantity} x {format_ghs(ln.unit_price)} = {format_ghs(ln.line_total)}"
            )
        out += ["-" * 42, f"Estimated total: {format_ghs(self.total)}", ""]
        if self.note:
            out += ["Customer note:", self.note, ""]
        out += [DISCLAIMER, ""]
        return "\n".join(out)

    def to_csv(self) -> str:
        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(["document", "ENQUIRY - NOT A CONFIRMED ORDER"])
        writer.writerow(["reference", self.reference])
        writer.writerow([])
        writer.writerow(["product_id", "name", "unit_price_ghs", "quantity", "line_total_ghs"])
        for ln in self.lines:
            writer.writerow([ln.product_id, ln.name, ln.unit_price, ln.quantity, ln.line_total])
        writer.writerow([])
        writer.writerow(["estimated_total_ghs", self.total])
        writer.writerow(["notice", "Shop must confirm price and stock. No payment taken."])
        return buf.getvalue()


def clean_text(value: str, max_length: int) -> str:
    """Strip control characters and cap the length of free text typed by the customer."""
    value = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", "", value or "").strip()
    return value[:max_length]


def build_enquiry(
    catalogue: pd.DataFrame,
    basket: Mapping[str, int],
    *,
    customer_name: str = "",
    note: str = "",
    now: datetime | None = None,
) -> Enquiry:
    """Validate every basket line against current stock and calculate totals.

    Raises EnquiryError listing every problem, so nothing invalid is ever downloaded.
    """
    if not basket:
        raise EnquiryError(["Your enquiry is empty. Add at least one product."])

    problems: list[str] = []
    lines: list[EnquiryLine] = []
    for product_id, qty in basket.items():
        product = get_product(catalogue, product_id)
        if product is None:
            problems.append(f"Product {product_id} is not in the catalogue.")
            continue
        result = check_quantity(product, qty)
        if not result.ok:
            problems.append(result.message)
            continue
        unit = to_money(product["price_ghs"])
        lines.append(
            EnquiryLine(product_id, product["name"], unit, int(qty), line_total(unit, int(qty)))
        )
    if problems:
        raise EnquiryError(problems)

    total = sum((ln.line_total for ln in lines), Decimal("0.00"))
    created = now or datetime.now(timezone.utc)
    return Enquiry(
        lines=lines,
        total=to_money(total),
        reference=f"ENQ-{created.strftime('%Y%m%d-%H%M%S')}",
        created_at=created,
        customer_name=clean_text(customer_name, MAX_NAME_LENGTH),
        note=clean_text(note, MAX_NOTE_LENGTH),
    )
